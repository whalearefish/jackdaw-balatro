"""Agent implementations (future)."""
